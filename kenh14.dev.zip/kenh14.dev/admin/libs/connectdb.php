<?php
if(isset($_POST['submit'])){
	$servername='localhost';
	$username='root';
	$password='';
	$dbname='kenh14';
}
try
{
	$dbc=new PDO('mysql: host=$servername; dbname=$dbname; charset=utf8',$username, $password);
	$dbc->getAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql="SELECT * FROM kenh14";
	$stmt=$dbc->prepare($sql);
	$stmt->execute();
	$stmt->setfetchMode(PDO::FETCH_ASSOC);
	$stmt->fetchALL();
	$dbc=null;
}
catch(PDOException $ex)
{
	echo $ex->getMessage();
}