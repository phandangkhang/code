<?php
  if(isset($_POST['submit'])){
    require("../libs/connectdb.php");
  }
 ?>



<!DOCTYPE html>
<html>
<head>																															

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="/admin/assets/css/dashboard.css">

	<title></title>
</head>
<body>

  <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Project name</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Settings</a></li>
            <li><a href="#">Profile</a></li>
            <li><a href="#">Help</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Search...">
          </form>
        </div>
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <?php
        require("../components/sidebar-left.php");// lay noi dung tu file sidebar-left.php
        ?>
        <form method="post" action="<?=$_SERVER['PHP_SELF']?>" enctype="multipart/form-data">
          <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Tao bai viet moi</h1>
          <form>
  <div class="form-group">
    <label for="exampleInputEmail1">Tieu de</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="title">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Mo ta</label>
    <textarea name="description" class="form-control"></textarea>
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Noi dung</label>
    <textarea class="form-control" id="content" name="content"></textarea>
   
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">hinh anh</label>
    <input type="file" class="form-control" id="exampleInputEmail1">
  </div>

  <div class="checkbox">
    <label>
      <input type="checkbox"> Check me out
    </label>
  </div>
  <button type="submit" class="btn btn-default" name="submit">Submit</button>
</form>
        </div>
        </form>
        
      </div>
    </div>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script type="text/javascript" src="/admin/assets/plugins/ckeditor/ckeditor.js"></script> 
 <script type="text/javascript">
       CKEDITOR.replace( 'content' );
    </script>
</body>
</html>