<div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class=""><a href="#">Overview <span class="sr-only">(current)</span></a></li>
           
          </ul>
          <ul class="nav nav-sidebar">
            <li <?= $_SERVER['REQUEST_URI']=='/admin/post/index.php'?'class="active"':''?>><a href="/admin/post/index.php">danh sach bai viet</a></li>
            <li <?= $_SERVER['REQUEST_URI']=='/admin/post/create.php'?'class="active"':''?>><a href="/admin/post/create.php">them bai viet</a></li>
            
          </ul>
          <ul class="nav nav-sidebar">
            
          </ul>
</div>